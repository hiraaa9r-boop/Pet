'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"canvaskit/chromium/canvaskit.js": "5e27aae346eee469027c80af0751d53d",
"canvaskit/chromium/canvaskit.js.symbols": "193deaca1a1424049326d4a91ad1d88d",
"canvaskit/chromium/canvaskit.wasm": "24c77e750a7fa6d474198905249ff506",
"canvaskit/canvaskit.js": "140ccb7d34d0a55065fbd422b843add6",
"canvaskit/canvaskit.js.symbols": "58832fbed59e00d2190aa295c4d70360",
"canvaskit/canvaskit.wasm": "07b9f5853202304d3b0749d9306573cc",
"canvaskit/skwasm.js": "1ef3ea3a0fec4569e5d531da25f34095",
"canvaskit/skwasm.js.symbols": "0088242d10d7e7d6d2649d1fe1bda7c1",
"canvaskit/skwasm.wasm": "264db41426307cfc7fa44b95a7772109",
"canvaskit/skwasm_heavy.js": "413f5b2b2d9345f37de148e2544f584f",
"canvaskit/skwasm_heavy.js.symbols": "3c01ec03b5de6d62c34e17014d1decd3",
"canvaskit/skwasm_heavy.wasm": "8034ad26ba2485dab2fd49bdd786837b",
"flutter.js": "888483df48293866f9f41d3d9274a779",
"flutter_bootstrap.js": "30ad37eccfa7916bd31f1fe7958e7221",
"index.html": "1d31debe6c599f33ea24f2e638149b84",
"/": "1d31debe6c599f33ea24f2e638149b84",
"main.dart.js": "12bdab2db653d90906f78cedde07e9fa",
"version.json": "eef11053172e8026c11376e724f7046f",
"assets/assets/images/logo.png": "cb10fb65c793cc8fd1f1bfe4ee392126",
"assets/assets/images/logo_web.png": "b695ab0e8b3e8e08c785b6c02771d05d",
"assets/assets/images/my_pet_care_logo.webp": "cb10fb65c793cc8fd1f1bfe4ee392126",
"assets/assets/images/app_icon.png": "f9611f93a50183f49b1f6b9ff688c6ad",
"assets/assets/images/my_pet_care_full_logo.png": "171e0227183e950040102b965f5ee64b",
"assets/assets/logo/my_pet_care_logo.webp": "f87e0719452afdfa9185de20d1ebab8f",
"assets/assets/logo/my_pet_care_logo.png": "cb10fb65c793cc8fd1f1bfe4ee392126",
"assets/assets/icons/pet_care_icon_512_bordered.png": "995ff7de0bedc6246c536fb6a6e756c5",
"assets/assets/icons/pet_care_icon_1024_bordered.png": "d21eaa28d685d62a16b3b470ea7c06f8",
"assets/assets/fonts/Poppins-Bold.ttf": "92934d92f57e49fc6f61075c2aeb7689",
"assets/assets/fonts/Inter-Regular.ttf": "cdcb960bf837a9ecc820001f9095cb3d",
"assets/fonts/MaterialIcons-Regular.otf": "83881c045d010ffed2f88aa49d3ec047",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.json": "1c08b432b0f8de8fff046773e1a6b46d",
"assets/AssetManifest.bin": "412328914fe6fb769955a830b02e5ae6",
"assets/AssetManifest.bin.json": "53d85a59673062a0a93209f962a4762a",
"assets/FontManifest.json": "e0dd17a2ca58fbf4c12be39729757b5a",
"assets/NOTICES": "796d3cae7d6ebca09a7dde655eea4730",
"icons/Icon-192.png": "41ff7fc79107b489f912f7731459d0d7",
"icons/Icon-512.png": "51b56c333887ad9b423e30cff25bf7b1",
"icons/Icon-maskable-192.png": "41ff7fc79107b489f912f7731459d0d7",
"icons/Icon-maskable-512.png": "51b56c333887ad9b423e30cff25bf7b1",
"favicon.png": "b68973b1e8121c3a97843ac8b9280071",
"manifest.json": "6b179dc98f43d936d12175313bbb0bd5",
"splash/img/light-1x.png": "e4459e81a132ae0a6917e866cf489385",
"splash/img/light-2x.png": "0f4fc0a808a4e023852a91d51534808d",
"splash/img/light-3x.png": "bacc1a32ce71753f26bd1f5ffe8cea38",
"splash/img/light-4x.png": "37dd7f56cccfe575a45f0a26510df6da",
"splash/img/dark-1x.png": "e4459e81a132ae0a6917e866cf489385",
"splash/img/dark-2x.png": "0f4fc0a808a4e023852a91d51534808d",
"splash/img/dark-3x.png": "bacc1a32ce71753f26bd1f5ffe8cea38",
"splash/img/dark-4x.png": "37dd7f56cccfe575a45f0a26510df6da",
"splash/img/branding-1x.png": "cbd63fd5c6cc8da85c632854482960f9",
"splash/img/branding-2x.png": "ae13d5ee86f085e2074748673327709b",
"splash/img/branding-3x.png": "692113fe154847ea01c9f66cc924da87",
"splash/img/branding-4x.png": "51b56c333887ad9b423e30cff25bf7b1",
"splash/img/branding-dark-1x.png": "cbd63fd5c6cc8da85c632854482960f9",
"splash/img/branding-dark-2x.png": "ae13d5ee86f085e2074748673327709b",
"splash/img/branding-dark-3x.png": "692113fe154847ea01c9f66cc924da87",
"splash/img/branding-dark-4x.png": "51b56c333887ad9b423e30cff25bf7b1"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
